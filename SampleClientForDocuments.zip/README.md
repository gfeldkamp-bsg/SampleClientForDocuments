# SampleClientForDocuments
Sample C# application that demonstrates how to consume Backstop documents rest api.
